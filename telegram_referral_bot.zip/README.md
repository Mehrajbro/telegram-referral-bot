# Telegram Referral Bot
A simple Telegram bot that rewards users for inviting others using referral links.